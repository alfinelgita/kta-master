<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Anggota extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'nia', 
        'nama_lengkap', 
        'jabatan_id', 
        'tempat_lahir',
        'tgl_lahir',
        'usia',
        'alamat',
        'desa',
        'kec',
        'kab',
        'prov',
        'telepon',
        'email',
        'foto'
    ];

    public function data_jabatan()
    {
        return $this->belongsTo('App\Jabatan', 'jabatan_id', 'id');
    }
}
