<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Jabatan extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'nama'
    ];

    public function data_anggota()
    {
        return $this->hasMany('App\Anggota', 'jabatan_id', 'id');
    }
}
