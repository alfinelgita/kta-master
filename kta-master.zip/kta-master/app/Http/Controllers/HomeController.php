<?php

namespace App\Http\Controllers;

use App\Anggota;
use App\Jabatan;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $anggotas = Anggota::get();
        $count_anggota = count($anggotas);

        $jabatans = Jabatan::get();
        $count_jabatan = count($jabatans);

        return view('home', ['anggota' => $count_anggota, 'jabatan' => $count_jabatan]);
    }
}
