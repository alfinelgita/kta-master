<?php

namespace App\Http\Controllers;

use App\Anggota;
use App\Jabatan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ClientController extends Controller
{
    public function index()
    {
        $jabatans = Jabatan::get();

        return view('welcome', ['jabatans' => $jabatans]);
    }

    public function insert(Request $request)
    {
        $image_name = null;
        if ($request->hasFile('foto')) {
            $image = $request->file('foto');
            $image_name = 'foto_' . time() . '.' . $image->getClientOriginalExtension();
            $path = public_path('/img');
            $image->move($path, $image_name);
        }

        $rand = rand(0000,9999);
        $nia = date("ymd" . $rand);

        $anggotas = Anggota::create([
            "nia" => $nia,
            "nama_lengkap" => $request->nama_lengkap,
            "jabatan_id" => $request->jabatan,
            "tempat_lahir" => $request->tempat_lahir,
            "tgl_lahir" => $request->tgl_lahir,
            "usia" => $request->usia,
            "alamat" => $request->alamat,
            "kec" => $request->kec,
            "kab" => $request->kab,
            "prov" => $request->prov,
            "telepon" => $request->telepon,
            "email" => $request->email,
            "foto" => $image_name
        ]);

        $request->session()->flash('status', 'Data berhasil diubah');

        return redirect()->route('index');
    }
}
