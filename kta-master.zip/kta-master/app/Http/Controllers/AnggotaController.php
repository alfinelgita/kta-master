<?php

namespace App\Http\Controllers;

use App\Anggota;
use App\Jabatan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class AnggotaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $anggotas = Anggota::with('data_jabatan')->get();

        return view('admin.anggota.index', ['anggotas' => $anggotas]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $jabatans = Jabatan::get();
        return view('admin.anggota.create', ['jabatans' => $jabatans]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $image_name = null;
        if ($request->hasFile('foto')) {
            $image = $request->file('foto');
            $image_name = 'foto_' . time() . '.' . $image->getClientOriginalExtension();
            $path = public_path('/img');
            $image->move($path, $image_name);
        }

        $rand = rand(0000,9999);
        $nia = date("ymd" . $rand);

        $anggotas = Anggota::create([
            "nia" => $nia,
            "nama_lengkap" => $request->nama_lengkap,
            "jabatan_id" => $request->jabatan,
            "tempat_lahir" => $request->tempat_lahir,
            "tgl_lahir" => $request->tgl_lahir,
            "usia" => $request->usia,
            "alamat" => $request->alamat,
            "desa" => $request->desa,
            "kec" => $request->kec,
            "kab" => $request->kab,
            "prov" => $request->prov,
            "telepon" => $request->telepon,
            "email" => $request->email,
            "foto" => $image_name
        ]);

        $request->session()->flash('status', 'Data berhasil diubah');

        return redirect()->route('anggota.create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $anggota = Anggota::with('data_jabatan')->find($id);
        $jabatans = Jabatan::get();

        return view('admin.anggota.edit', ['anggota' => $anggota, 'jabatans' => $jabatans]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $anggota = Anggota::find($id);
        $anggota->nama_lengkap = $request->nama_lengkap;
        $anggota->jabatan_id = $request->jabatan;
        $anggota->tempat_lahir = $request->tempat_lahir;
        $anggota->tgl_lahir = $request->tgl_lahir;
        $anggota->usia = $request->usia;
        $anggota->alamat = $request->alamat;
        $anggota->kec = $request->kec;
        $anggota->kab = $request->kab;
        $anggota->prov = $request->prov;
        $anggota->telepon = $request->telepon;
        $anggota->email = $request->email;
        
        if ($request->hasFile('foto')) {
            $destinationPath = public_path('/img');
            File::delete($destinationPath . '/' . $anggota->foto);

            $image = $request->file('foto');
            $image_name = 'anggota_' . time() . '.' . $image->getClientOriginalExtension();
            $path = public_path('/img');
            $image->move($path, $image_name);

            $anggota->foto = $image_name;
        }

        $anggota->save();

        $request->session()->flash('status', 'Data berhasil diubah');
        
        return redirect()->route('anggota.edit', ['id' => $id]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        $anggota = Anggota::find($id);
        $anggota->delete();

        $request->session()->flash('status', 'Data berhasil dihapus');

        return redirect()->route('anggota.index');
    }
}
