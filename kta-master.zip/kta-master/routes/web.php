<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'ClientController@index')->name('index');

Route::post('/insert', 'ClientController@insert')->name('client.insert');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/anggota', 'AnggotaController@index')->name('anggota');
Route::get('/jabatan', 'JabatanController@index')->name('jabatan');

Route::group(['middleware' => 'auth'], function() {
    Route::get('anggota/{id}/delete', 'AnggotaController@destroy')->name('anggota.destroy');
    Route::resource('anggota', 'AnggotaController');
    
    Route::get('jabatan/{id}/delete', 'JabatanController@destroy')->name('jabatan.destroy');
    Route::resource('jabatan', 'JabatanController');
});
