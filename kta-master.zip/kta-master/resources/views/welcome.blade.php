<style>
    @import url(https://fonts.googleapis.com/css?family=Roboto:400,300,500);
*:focus {
  outline: none;
}

body {
  margin: 0;
  padding: 0;
  background: #DDD;
  font-size: 16px;
  color: #222;
  font-family: 'Roboto', sans-serif;
  font-weight: 300;
}

#login-box {
  position: relative;
  margin: 2% auto;
  width: 900px;
  height: 550px;
  background: #FFF;
  border-radius: 2px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.4);
}

.left {
  position: absolute;
  top: 0;
  left: 0;
  box-sizing: border-box;
  padding: 40px;
  width: 580px;
  height: 400px;
}

.sukses {
  margin: 0 0 10px 0;
  background-color: lightgreen;
  color: #303030;
  padding: 10px;
  text-align: center;
}

h1 {
  margin: 0 0 20px 0;
  font-weight: 300;
  font-size: 28px;
}

input[type="text"],
input[type="password"] {
  display: block;
  box-sizing: border-box;
  margin-bottom: 20px;
  padding: 4px;
  width: 220px;
  height: 32px;
  border: none;
  border-bottom: 1px solid #AAA;
  font-family: 'Roboto', sans-serif;
  font-weight: 400;
  font-size: 15px;
  transition: 0.2s ease;
}

select {
  display: block;
  box-sizing: border-box;
  margin-bottom: 20px;
  padding: 4px;
  width: 220px;
  height: 32px;
  border: none;
  border-bottom: 1px solid #AAA;
  font-family: 'Roboto', sans-serif;
  font-weight: 400;
  font-size: 15px;
  transition: 0.2s ease;
  background-color: #fff;
}

input[type="text"]:focus,
input[type="password"]:focus,
select:focus {
  border-bottom: 2px solid #16a085;
  color: #16a085;
  transition: 0.2s ease;
}

input[type="submit"] {
  margin-top: 28px;
  width: 120px;
  height: 32px;
  background: #16a085;
  border: none;
  border-radius: 2px;
  color: #FFF;
  font-family: 'Roboto', sans-serif;
  font-weight: 500;
  text-transform: uppercase;
  transition: 0.1s ease;
  cursor: pointer;
}

input[type="submit"]:hover,
input[type="submit"]:focus {
  opacity: 0.8;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.4);
  transition: 0.1s ease;
}

input[type="submit"]:active {
  opacity: 1;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
  transition: 0.1s ease;
}

.or {
  position: absolute;
  top: 180px;
  left: 280px;
  width: 40px;
  height: 40px;
  background: #DDD;
  border-radius: 50%;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.4);
  line-height: 40px;
  text-align: center;
}

.right {
  position: absolute;
  top: 0;
  right: 0;
  box-sizing: border-box;
  padding: 40px;
  width: 300px;
  height: 550px;
  background: url('https://goo.gl/YbktSj');
  background-size: cover;
  background-position: center;
  border-radius: 0 2px 2px 0;
}

.right .loginwith {
  display: block;
  margin-bottom: 40px;
  font-size: 28px;
  color: #FFF;
  text-align: center;
}

button.social-signin {
  margin-bottom: 20px;
  width: 220px;
  height: 36px;
  border: none;
  border-radius: 2px;
  color: #FFF;
  font-family: 'Roboto', sans-serif;
  font-weight: 500;
  transition: 0.2s ease;
  cursor: pointer;
}

button.social-signin:hover,
button.social-signin:focus {
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.4);
  transition: 0.2s ease;
}

button.social-signin:active {
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
  transition: 0.2s ease;
}

button.social-signin.facebook {
  background: #32508E;
}

button.social-signin.twitter {
  background: #55ACEE;
}

button.social-signin.google {
  background: #DD4B39;
}
</style>
<div id="login-box">
  <div class="left">
      @if(session('status'))
        <p class="sukses">Sukses !!</p>
      @endif    
    <h1>Register</h1>
    <form action="{{ url('insert') }}" method="POST" enctype="multipart/form-data">
      @csrf
      <div style="float: left;">      
        <input type="text" name="nama_lengkap" placeholder="Nama Lengkap" />
        <input type="text" name="tempat_lahir" placeholder="Tempat Lahir" />
        <input type="text" id="tgl_lahir" name="tgl_lahir" placeholder="Tanggal Lahir (YYYY-MM-DD)" />
        <input type="text" id="usia" name="usia" placeholder="Usia" readonly />
        <input type="text" name="alamat" placeholder="Alamat" /> 
        <input type="file" name="foto" placeholder="Foto" /><br>                
        <input type="submit" name="signup" value="Sign up" />
      </div>
      <div style="float: left; margin-left:10px;">
        <input type="text" name="kec" placeholder="Kecamatan" />
        <input type="text" name="kab" placeholder="Kabupaten" />
        <input type="text" name="prov" placeholder="Provinsi" />
        <input type="text" name="telepon" placeholder="Telepon" />
        <input type="text" name="email" placeholder="Email" />
        <select name="jabatan">
          @foreach ($jabatans as $jabatan)
              <option value="{{ $jabatan->id }}">{{ $jabatan->nama }}</option>
          @endforeach
        </select>
      </div>   
    </form>   
  </div>    
  <div class="right" style="border-left: 1px solid #a0a0a0;">
    <center><img src="{{ asset('img/logo.png') }}" alt="" style="max-width: 200px; margin-top: 10%;"></center>
    <h3>
      Form Formulir Pendataan Anggota IPNU - IPPNU ( Kota, Kecamatan, Ranting dan Komisariat )
    </h3>
    <p style="text-align: justify;">
      Isilah form disamping dengan benar dan sesuai data yang ada, guna untuk pembuatan arsip data kepengurusan dan pembuatan KTA.
    </p>
  </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>
    $(document).ready(function(){
      //$("#tgl_lahir").datepicker({ dateFormat: 'dd-mm-yy' });
      $("#tgl_lahir").on("mouseout keyup", function(){
        var tgl_lahir = $(this).val();
        var tgl_split = tgl_lahir.split('-');
        var d = new Date();
        //var strDate = d.getFullYear() + "/" + (d.getMonth()+1) + "/" + d.getDate();
        var tahun_old = tgl_split[0];
        var tahun_now = d.getFullYear();
        var usia = tahun_now - tahun_old;
        if(tgl_lahir == ''){
          $("#usia").val("");
        }
        else{
          $("#usia").val(usia);
        }
      });
    });
  </script>