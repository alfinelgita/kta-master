@extends('layouts.app')

@section('style')
    <!-- DataTables -->
    <link rel="stylesheet" href="{{ asset('adminlte/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css') }}">
@endsection

@section('content')
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        Jabatan
    </h1>
    <ol class="breadcrumb">
        <li><a href="{{ url('/home') }}"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Jabatan</li>
    </ol>
</section>

<!-- Main content -->
<section class="content">
        <div class="box">
            @if(session('status'))
                <div class="alert alert-success">
                    {{session('status')}}
                </div>
            @endif
            <div class="box-header">
                <a href="{{ route('jabatan.create') }}" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah</a>
            </div>
            <!-- /.box-header -->
            <hr>
            <div class="box-body">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th style="text-align: center;">No</th>
                            <th style="text-align: center;">Nama</th>
                            <th style="text-align: center;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($jabatans as $key => $jabatan)
                            <tr>
                                <td style="text-align: center;">{{ $key + 1 }}</td>
                                <td>{{ $jabatan->nama }}</td>
                                <td>
                                    <div class="text-center">
                                        <div id="button-container" class="btn-group">                            
                                            <a 
                                                href="{{ route('jabatan.edit', ['id' => $jabatan->id]) }}" 
                                                class="btn btn-info">
                                                <i class="fa fa-edit"></i>
                                            </a>
                                            <a 
                                                href="{{ url('jabatan/' . $jabatan->id . '/delete') }}" 
                                                class="btn btn-danger" 
                                                onclick="return confirm('Delete this data permanently?')">
                                                <i class="fa fa-trash"></i>
                                            </a>                            
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </section>
@endsection

@section('script')
<!-- DataTables -->
<script src="{{ asset('adminlte/bower_components/datatables.net/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('adminlte/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js') }}"></script>

<script>
    $(function () {
        $('#example1').DataTable()
        $('#example2').DataTable({
            'paging'      : true,
            'lengthChange': false,
            'searching'   : false,
            'ordering'    : true,
            'info'        : true,
            'autoWidth'   : false
        })
    })
</script>    
@endsection
