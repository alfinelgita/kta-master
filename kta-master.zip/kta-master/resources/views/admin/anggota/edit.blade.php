@extends('layouts.app')

@section('content')
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        Anggota Ubah
    </h1>
    <ol class="breadcrumb">
        <li><a href="{{ url('/home') }}"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><a href="{{ url('/anggota') }}">Anggota</a></li>
        <li class="active">Ubah</li>
    </ol>
</section>

<!-- Main content -->
<section class="content">
    <div class="box">
        @if(session('status'))
            <div class="alert alert-success">
                {{session('status')}}
            </div>
        @endif
        <form action="{{ route('anggota.update', ['id' => $anggota->id]) }}" method="POST" enctype="multipart/form-data">
            @method('PUT')
            @csrf
            <div class="box-body">
                <div class="row">
                    <div class="form-group col-md-4">
                        <label for="nama_lengkap">Nama Lengkap</label>
                        <input type="text" class="form-control" name="nama_lengkap" value="{{ $anggota->nama_lengkap }}">
                    </div>
                    <div class="form-group col-md-4">
                        <label for="tempat_lahir">Tempat Lahir</label>
                        <input type="text" class="form-control" name="tempat_lahir" value="{{ $anggota->tempat_lahir }}">
                    </div>
                    <div class="form-group col-md-4">
                        <label for="tgl_lahir">Tanggal Lahir (YYYY-MM-DD)</label>
                        <input type="text" id="tgl_lahir" class="form-control" name="tgl_lahir" value="{{ $anggota->tgl_lahir }}">
                    </div>
                    <div class="form-group col-md-4">
                        <label for="usia">Usia</label>
                        <input type="text" id="usia" class="form-control" name="usia" value="{{ $anggota->usia }}" readonly>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="alamat">Alamat</label>
                        <input type="text" class="form-control" name="alamat" value="{{ $anggota->alamat }}">
                    </div>
                    <div class="form-group col-md-4">
                        <label for="kec">Kecamatan</label>
                        <input type="text" class="form-control" name="kec" value="{{ $anggota->kec }}">
                    </div>
                    <div class="form-group col-md-4">
                        <label for="kab">Kabupaten</label>
                        <input type="text" class="form-control" name="kab" value="{{ $anggota->kab }}">
                    </div>
                    <div class="form-group col-md-4">
                        <label for="prov">Provinsi</label>
                        <input type="text" class="form-control" name="prov" value="{{ $anggota->prov }}">
                    </div>
                    <div class="form-group col-md-4">
                        <label for="telepon">Telepon</label>
                        <input type="text" class="form-control" name="telepon" value="{{ $anggota->telepon }}">
                    </div>
                    <div class="form-group col-md-4">
                        <label for="email">Email</label>
                        <input type="text" class="form-control" name="email" value="{{ $anggota->email }}">
                    </div>
                    <div class="form-group col-md-4">
                        <label for="nama">Jabatan</label>
                        <select name="jabatan" id="jabatan" class="form-control">
                            @foreach ($jabatans as $jabatan)
                                <option 
                                @if ($jabatan->id == $anggota->jabatan_id)
                                    selected
                                @endif 
                                value="{{ $jabatan->id }}">{{ $jabatan->nama }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="foto">Foto</label>
                        <input type="file" class="form-control" name="foto">
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-12">
                        <button class="btn btn-primary">Simpan</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <!-- /.box -->
</section>
@endsection

@section('script')
    <script>
        $(document).ready(function(){
          //$("#tgl_lahir").datepicker({ dateFormat: 'dd-mm-yy' });
            $("#tgl_lahir").on("mouseout keyup", function(){
                var tgl_lahir = $(this).val();
                var tgl_split = tgl_lahir.split('-');
                var d = new Date();
                //var strDate = d.getFullYear() + "/" + (d.getMonth()+1) + "/" + d.getDate();
                var tahun_old = tgl_split[0];
                var tahun_now = d.getFullYear();
                var usia = tahun_now - tahun_old;
                if(tgl_lahir == ''){
                $("#usia").val("");
                }
                else{
                $("#usia").val(usia);
                }
            });
        });
    </script>
@endsection
